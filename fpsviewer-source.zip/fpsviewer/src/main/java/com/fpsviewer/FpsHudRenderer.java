package com.fpsviewer;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

public class FpsHudRenderer implements HudRenderCallback {

    @Override
    public void onHudRender(DrawContext drawContext, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.getDebugHud().shouldShowDebugHud()) return;

        int fps = client.getCurrentFps();
        String fpsText = "FPS: " + fps;

        int color;
        if (fps >= 60) {
            color = 0xFF00FF00; // hijau
        } else if (fps >= 30) {
            color = 0xFFFFFF00; // kuning
        } else {
            color = 0xFFFF0000; // merah
        }

        drawContext.drawTextWithShadow(client.textRenderer, fpsText, 4, 4, color);
    }
}
